from django.db import models

class Board(models.Model):
	boardNo = models.IntegerField(primary_key = True)
	vacancies = models.IntegerField()
	active = models.BooleanField(default = True)


	
class Player(models.Model):
	Code = models.IntegerField(primary_key = True)
	First_Name = models.CharField(max_length=40)
	Last_Name = models.CharField(max_length=40)
	Position = models.IntegerField(default = 0)
	Board_No = models.ForeignKey(Board, on_delete = models.CASCADE)