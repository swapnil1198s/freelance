from django import forms
from .models import Player
from .models import Board


class BoardForm(forms.ModelForm):
	class Meta:
		model = Player
		fields = ('First_Name', 'Last_Name', 'Code', 'Board_No')
		
class showForm(forms.Form):
	Board_No= forms.IntegerField(label='Your Board Number')
