function changeText() {

  var names = ["Swapnil", "Dillon"];
  var position = ["z", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"];
  for(i = 0; i<names.length; i++){
  	var x = document.getElementsByClassName(position[i]);
  	x[0].innerHTML = names[i];
  }
  
}