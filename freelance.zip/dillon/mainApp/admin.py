from django.contrib import admin
from .models import Player
from .models import Board

admin.site.register(Player)
admin.site.register(Board)
 