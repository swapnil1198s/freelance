from django.urls import path
from .import views

urlpatterns = [
    path('', views.home.as_view(), name = "Home"),
    path('about/', views.about, name = "About"),
    path('enter/', views.EnterBoard.as_view(), name = "Enter-board"),
    path('contact/', views.contact, name = "Contact"),
]