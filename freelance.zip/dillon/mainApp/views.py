from django.shortcuts import render
from django.views.generic import TemplateView
from django.http import HttpResponse
from .forms import BoardForm
from .forms import showForm
from .models import Player
from .models import Board




class EnterBoard(TemplateView):
	templateName = 'mainApp/enter.html'
	def get(self, request):
		form = BoardForm()
		return render(request, self.templateName, {'form': form})

	def post(self, request):
		form = BoardForm(request.POST)
		if form.is_valid():
			newP = form.save()
			form = BoardForm()
		return render(request, self.templateName, {'form': form})

class home(TemplateView):
	templateName = 'mainApp/index.html'
	def get(self, request):
		form = showForm()
		context = {
				'form': form,
				'title': 'Home'
			}
		return render(request, self.templateName, context)

	def post(self, request):
		form = showForm(request.POST)
		if form.is_valid():
			bNo = form.cleaned_data['Board_No']
			players = Player.objects.all()
			board = players.filter(Board_No = bNo)
			context = {
				'form': form,
				'board': board,
				'title': 'Board'
			}
		return render(request, 'mainApp/homeb.html', context)


def about(request):
	return render(request, 'mainApp/about.html', {'title': 'About'})

def contact(request):
	return render(request, 'mainApp/contact.html', {'title': 'Contact'})
# Create your views here.
